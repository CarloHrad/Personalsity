package com.example.trinots.exception.exceptions;

import org.springframework.http.HttpStatus;

public class DisciplinaImutavelException extends NegocioException {
    public DisciplinaImutavelException(String message) {
        super(message, HttpStatus.UNPROCESSABLE_ENTITY, "DISCIPLINA_IMUTAVEL");
    }
}