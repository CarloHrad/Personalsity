package com.example.trinots.exception.exceptions;

import org.springframework.http.HttpStatus;

public class HorarioIntervaloInvalidoException extends NegocioException {
    public HorarioIntervaloInvalidoException(String message) {
        super(message, HttpStatus.UNPROCESSABLE_ENTITY, "HORARIO_INTERVALO_INVALIDO");
    }
}